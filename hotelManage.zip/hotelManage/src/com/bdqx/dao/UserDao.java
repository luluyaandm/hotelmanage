package com.bdqx.dao;

import com.bdqx.pojo.User;

import java.sql.SQLException;
import java.util.List;

public interface UserDao {

    public User findUser(String userName,String userPwd);

    public List<User> findAlluser() throws SQLException;

    public int findTotalCount();

    public List<User> findByPage(int start,int rows);

    public void addUser(User user) throws SQLException;

    public int updateUserPwd(String userName,String newPwd);

    public User findUserById(String userID)throws SQLException;

    public void updateUser(User user) throws SQLException;

    public void deleteUser(String userID) throws SQLException;

    public List<User> listUser() throws SQLException;
}
