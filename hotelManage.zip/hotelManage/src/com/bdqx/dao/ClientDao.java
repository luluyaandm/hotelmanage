package com.bdqx.dao;

import com.bdqx.pojo.Client;
import com.bdqx.pojo.Record;

import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

public interface ClientDao {
    public Client findClientByID(String clientID) throws SQLException;
    public List<Client> listClient() throws SQLException;
    public List<Client> listPageClient(int currentPage, int pageRecordNum) throws SQLException;
    public List<Record> listClientOnline() throws SQLException;
    public List<Record> listPageClientOnline(int currentPage, int pageRecordNum) throws SQLException;
    public void updateClient(Client client) throws SQLException;
    public void addClinet(Client client) throws SQLException;
    public void deleteClient(String clientID) throws SQLException;
    public List<Client> searchClient(String sql) throws SQLException;
    public void checkOutClinet(String clientID, String bookInDate, String checkDate) throws SQLException;
    public List<Record> searchClientOnline(String sql) throws SQLException;
}
