package com.bdqx.dao;

import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

import com.bdqx.pojo.Record;

public interface RecordDao {
    public List<Record> listRecord() throws SQLException;
    public List<Record> listPageRecord(int currentPage, int pageNum) throws SQLException;

    public Record findRcord(String clientID, Date bookInDate) throws SQLException;

    public void updateRecord(Record record) throws SQLException;

    public void deleteRecord(String clientID, Date bookInDate) throws SQLException;

    public void addRecord(Record record) throws SQLException;

    public List<Record> searchRecord(String sql) throws SQLException;

    public Record findOnlineClient(String clientID, String bookInDate) throws SQLException;
}
