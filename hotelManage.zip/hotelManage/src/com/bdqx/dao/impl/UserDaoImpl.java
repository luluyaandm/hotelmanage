package com.bdqx.dao.impl;

import com.bdqx.dao.UserDao;
import com.bdqx.pojo.User;
import com.bdqx.util.C3P0Util;
import com.bdqx.util.C3P0Util;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserDaoImpl implements UserDao {

    @Override
    public User findUser(String userName, String userPwd) {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        User user = null;

        try {
            connection=C3P0Util.getConnection();
            statement = connection.prepareStatement("select * from user where userName=?and userPwd=?");
            statement.setString(1,userName);
            statement.setString(2,userPwd);
            resultSet=statement.executeQuery();
            if (resultSet.next()){
                user = new User();
                user.setUserID(resultSet.getInt("userID"));
                user.setUserName(resultSet.getString("userName"));
                user.setUserPwd(resultSet.getString("userPwd"));
                user.setUserEmail(resultSet.getString("userEmail"));
                user.setUserPhone(resultSet.getString("userPhone"));
                user.setUserInformation(resultSet.getString("userInformation"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            C3P0Util.release(connection,resultSet,statement);
        }
        return user;
    }
    JdbcTemplate template = new JdbcTemplate(C3P0Util.getDataSource());
    @Override
    public List<User> findAlluser()  {

        List<User> users = template.query("select * from user",new BeanPropertyRowMapper<User>(User.class));
        return users;

    }

    @Override
    public int findTotalCount() {
        StringBuffer stringBuffer = new StringBuffer("select count(*) from user");

        List<Object> params = new ArrayList<Object>();
        System.out.println(stringBuffer.toString());
        System.out.println(params);

        return template.queryForObject(stringBuffer.toString(),Integer.class,params.toArray());
    }

    @Override
    public List<User> findByPage(int start, int rows) {
        String sql = "select * from user";
        StringBuffer stringBuffer=new StringBuffer(sql);
        List<Object> params = new ArrayList<Object>();
        stringBuffer.append(" limit ?,? ");
        params.add(start);
        params.add(rows);
        sql = stringBuffer.toString();
        System.out.println(sql);
        System.out.println(params);

        return template.query(sql,new BeanPropertyRowMapper<User>(User.class),params.toArray());
    }

    @Override
    public int updateUserPwd(String userName,String newPwd) {
        Connection connection = null;
        PreparedStatement statement = null;
        int i = 0;
        try {
            connection = C3P0Util.getConnection();
            statement = connection.prepareStatement("update user set userPwd = ? where userName =?");
            statement.setString(1, newPwd);
            statement.setString(2, userName);
            i = statement.executeUpdate();
            if (i > 0) {
                System.out.println("success!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            C3P0Util.release(connection,null,statement);
        }
        return i;
    }

    @Override
    public void addUser(User user) throws SQLException{
        QueryRunner queryRunner = new QueryRunner(C3P0Util.getDataSource());
        queryRunner.update("insert into user values(?,?,?,?,?,?)",
                user.getUserID(),user.getUserName(),user.getUserPwd(),user.getUserEmail(),user.getUserPhone(),user.getUserInformation());
    }

    @Override
    public User findUserById(String userID) throws SQLException{
        QueryRunner queryRunner = new QueryRunner(C3P0Util.getDataSource());

        return queryRunner.query("select * from user where userID = ?",new BeanHandler<User>(User.class),userID);
    }

    @Override
    public void updateUser(User user) throws SQLException {
        QueryRunner queryRunner = new QueryRunner(C3P0Util.getDataSource());
        queryRunner.update("update user set userName = ?,userEmail = ?,userPhone = ? ,userInformation = ?where userID = ?",
                user.getUserName(),user.getUserEmail(),user.getUserPhone(),user.getUserInformation(),user.getUserID());
    }

    @Override
    public void deleteUser(String userID) throws SQLException {
        QueryRunner queryRunner = new QueryRunner(C3P0Util.getDataSource());
        queryRunner.update("delete from user where userID = ?",userID);
    }

    @Override
    public List<User> listUser() throws SQLException {
        QueryRunner qr = new QueryRunner(C3P0Util.getDataSource());
        return qr.query("select * from user", new BeanListHandler<User>(User.class));
    }
}
