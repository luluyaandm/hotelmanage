package com.bdqx.dao.impl;

import com.bdqx.dao.RecordDao;
import com.bdqx.pojo.Record;
import com.bdqx.util.C3P0Util;
import com.mysql.cj.xdevapi.PreparableStatement;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import javax.xml.crypto.Data;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

public class RecordDaoImpl implements RecordDao {

    @Override
    public List<Record> listRecord() throws SQLException {
        QueryRunner qr = new QueryRunner(C3P0Util.getDataSource());
        String sql = "select * from clientbookin";
        return qr.query(sql, new BeanListHandler<Record>(Record.class));
    }

    @Override
    public List<Record> listPageRecord(int currentPage, int pageNum) throws SQLException {
        QueryRunner qr = new QueryRunner(C3P0Util.getDataSource());
        String sql = "select * from clientbookin limit ?,?";
        final List<Record> list = qr.query(sql, new BeanListHandler<Record>(Record.class), currentPage, pageNum);
        return list;
    }

    @Override
    public Record findRcord(String clientID, Date bookInDate) throws SQLException {
        QueryRunner qr = new QueryRunner(C3P0Util.getDataSource());
        String sql = "select * from clientbookin where clientID = ? and bookInDate = ?";
        return qr.query(sql, new BeanHandler<Record>(Record.class), clientID, bookInDate);
    }

    @Override
    public void updateRecord(Record record) throws SQLException {
        QueryRunner qr = new QueryRunner(C3P0Util.getDataSource());
        String sql = "update  clientbookin  set roomID=? , totalMoney=? , checkDate=? , remark=?  where clientID=? and bookInDate=?";
        qr.update(sql, record.getRoomID(), record.getTotalMoney(), record.getCheckDate(), record.getRemark(), record.getClientID(), record.getBookInDate());
    }

    @Override
    public void deleteRecord(String clientID, Date bookInDate) throws SQLException {
        QueryRunner qr = new QueryRunner(C3P0Util.getDataSource());
        String sql = "delete from clientbookin where clientID=? and bookInDate=?";
        qr.update(sql, clientID, bookInDate);
    }

    @Override
    public void addRecord(Record record) throws SQLException {
        QueryRunner qr = new QueryRunner(C3P0Util.getDataSource());
        String sql = "insert into clientbookin values(?,?,?,?,?,?,?)";
        qr.update(sql, record.getClientName(), record.getClientID(), record.getRoomID()
                , record.getBookInDate(), record.getCheckDate(),record.getTotalMoney(), record.getRemark());
    }

    @Override
    public List<Record> searchRecord(String sql) throws SQLException {
        QueryRunner qr = new QueryRunner(C3P0Util.getDataSource());
        return qr.query(sql, new BeanListHandler<Record>(Record.class));
    }

    @Override
    public Record findOnlineClient(String clientID, String bookInDate) throws SQLException {
        QueryRunner qr = new QueryRunner(C3P0Util.getDataSource());
        return qr.query("select * from clientbookin where clientID=? and bookInDate=? and checkDate is null"
                , new BeanHandler<Record>(Record.class), clientID, bookInDate);
    }
}
