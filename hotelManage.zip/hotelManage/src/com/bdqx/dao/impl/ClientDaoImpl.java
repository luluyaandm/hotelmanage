package com.bdqx.dao.impl;

import com.bdqx.dao.ClientDao;
import com.bdqx.pojo.Client;
import com.bdqx.pojo.Record;
import com.bdqx.util.C3P0Util;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import java.sql.SQLException;
import java.util.List;

public class ClientDaoImpl implements ClientDao {
    @Override
    public Client findClientByID(String clientID) throws SQLException {
        QueryRunner qr = new QueryRunner(C3P0Util.getDataSource());
        String sql = "select * from client where clientID = ?";
        return qr.query(sql, new BeanHandler<Client>(Client.class), clientID);
    }


    @Override
    public List<Client> listClient() throws SQLException {
        QueryRunner qr = new QueryRunner(C3P0Util.getDataSource());
        return qr.query("select * from client", new BeanListHandler<Client>(Client.class));
    }

    @Override
    public List<Client> listPageClient(int currentPage, int pageRecordNum) throws SQLException {
        QueryRunner qr = new QueryRunner(C3P0Util.getDataSource());
        return qr.query("select * from client limit ?,?",new BeanListHandler<Client>(Client.class), currentPage, pageRecordNum);
    }

    @Override
    public List<Record> listClientOnline() throws SQLException {
        QueryRunner qr = new QueryRunner(C3P0Util.getDataSource());
        return qr.query("select * from clientbookin where checkDate is null", new BeanListHandler<Record>(Record.class));
    }

    @Override
    public List<Record> listPageClientOnline(int currentPage, int pageRecordNum) throws SQLException {
        QueryRunner qr = new QueryRunner(C3P0Util.getDataSource());
        return qr.query("select * from clientbookin where checkDate is null limit ?,?",new BeanListHandler<Record>(Record.class), currentPage, pageRecordNum);
    }


    @Override
    public void updateClient(Client client) throws SQLException {
        QueryRunner qr = new QueryRunner(C3P0Util.getDataSource());
        String sql = "update  client  set clientPhone=?,isVip=?,clientName=? where clientID=?";
        qr.update(sql, client.getClientPhone(), client.getIsVip(), client.getClientName(), client.getClientID());
    }

    @Override
    public void addClinet(Client client) throws SQLException {
        QueryRunner qr = new QueryRunner(C3P0Util.getDataSource());
        qr.update("insert into client values(?,?,?,?,?)", client.getClientName(), client.getClientID()
                    , client.getClientSex(),client.getClientPhone(), client.getIsVip());
    }

    @Override
    public void deleteClient(String clientID) throws SQLException {
        QueryRunner qr = new QueryRunner(C3P0Util.getDataSource());
        qr.update("delete from client where clientID=?",clientID);
    }

    @Override
    public List<Client> searchClient(String sql) throws SQLException {
        QueryRunner qr = new QueryRunner(C3P0Util.getDataSource());
        return qr.query(sql, new BeanListHandler<Client>(Client.class));
    }

    @Override
    public void checkOutClinet(String clientID, String bookInDate, String checkDate) throws SQLException {
        QueryRunner qr = new QueryRunner(C3P0Util.getDataSource());
        qr.update("update clientbookin set checkDate=? where clientID=? and bookInDate=?", checkDate, clientID, bookInDate);
    }

    @Override
    public List<Record> searchClientOnline(String sql) throws SQLException {
        QueryRunner qr = new QueryRunner(C3P0Util.getDataSource());
        return qr.query(sql, new BeanListHandler<Record>(Record.class));
    }

}
