package com.bdqx.dao.impl;


import com.bdqx.pojo.Room;
import com.bdqx.util.C3P0Util;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import java.sql.SQLException;
import java.util.List;

public class RoomDaoImpl  {
    /**
     * 查询所有房间
     * @return
     * @throws SQLException
     */
    public List<Room> findAllRoom() throws SQLException {
        QueryRunner qr = new QueryRunner(C3P0Util.getDataSource());
        return qr.query("select * from room",new BeanListHandler<Room>(Room.class));
    }

    public void addRoom(Room room) throws SQLException {
        QueryRunner qr =new QueryRunner(C3P0Util.getDataSource());
        qr.update("insert into room values(?,?,?,?,?,?)",room.getRoomID(),room.getRoomTypeName(),room.getRoomPosition(),room.getBedNum(),room.getPeopleNum(),room.getFactPeopleNum());
    }

    /**
     *
     * @param roomID
     * @return
     * @throws SQLException
     */
    public Room findRoomById(String roomID) throws SQLException {
        QueryRunner qr = new QueryRunner(C3P0Util.getDataSource());
        return qr.query("select * from room where roomID=?", new BeanHandler<Room>(Room.class),roomID);
    }

    /**
     * 修改房间信息
     * @param room
     * @throws SQLException
     */
    public void updateRoom(Room room) throws SQLException {
        QueryRunner qr = new QueryRunner(C3P0Util.getDataSource());
        qr.update("update room set roomTypeName=?,roomPosition=?,bedNum=?,peopleNum=?,factPeopleNum=? where roomID=?",
               room.getRoomTypeName(),room.getRoomPosition(),room.getBedNum(),room.getPeopleNum(),room.getFactPeopleNum(),room.getRoomID());
    }

    /**
     * 删除房间
     * @param roomID
     * @throws SQLException
     */
    public void deleteRoom(String roomID) throws SQLException {
        QueryRunner qr = new QueryRunner(C3P0Util.getDataSource());
        qr.update("delete from room where roomID=?",roomID);
    }

    public List<Room> findRoomByType(String roomTypeName) throws SQLException {
        QueryRunner qr = new QueryRunner(C3P0Util.getDataSource());
        return qr.query("select * from room where roomTypeName=? and roomID not in(select roomID from clientbookin where checkDate is null)"
                        , new BeanListHandler<Room>(Room.class), roomTypeName);
    }

}
