package com.bdqx.dao;

import com.bdqx.pojo.Room;

import java.util.List;
import java.util.Map;

public interface Pagedao {

    /**
     * 查询总记录数
     * @return
     * @param condition
     */
    int findTotalCount(Map<String, String[]> condition);

    /**
     * 分页查询每页记录
     * @param start
     * @param rows
     * @param condition
     * @return
     */
    List<Room> findByPage(int start, int rows, Map<String, String[]> condition);
}
