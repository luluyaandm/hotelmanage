package com.bdqx.pojo;

public class Room {
    private String  roomID;
    private String  roomTypeName;
    private String  roomPosition;
    private int  bedNum;
    private int  peopleNum;
    private int  factPeopleNum;

    @Override
    public String toString() {
        return "Room{" +
                "roomID='" + roomID + '\'' +
                ", roomTypeName='" + roomTypeName + '\'' +
                ", roomPosition='" + roomPosition + '\'' +
                ", bedNum=" + bedNum +
                ", peopleNum=" + peopleNum +
                ", factPeopleNum=" + factPeopleNum +
                '}';
    }

    public String getRoomID() {
        return roomID;
    }

    public void setRoomID(String roomID) {
        this.roomID = roomID;
    }

    public String getRoomTypeName() {
        return roomTypeName;
    }

    public void setRoomTypeName(String roomTypeName) {
        this.roomTypeName = roomTypeName;
    }

    public String getRoomPosition() {
        return roomPosition;
    }

    public void setRoomPosition(String roomPosition) {
        this.roomPosition = roomPosition;
    }

    public int getBedNum() {
        return bedNum;
    }

    public void setBedNum(int bedNum) {
        this.bedNum = bedNum;
    }

    public int getPeopleNum() {
        return peopleNum;
    }

    public void setPeopleNum(int peopleNum) {
        this.peopleNum = peopleNum;
    }

    public int getFactPeopleNum() {
        return factPeopleNum;
    }

    public void setFactPeopleNum(int factPeopleNum) {
        this.factPeopleNum = factPeopleNum;
    }
}
