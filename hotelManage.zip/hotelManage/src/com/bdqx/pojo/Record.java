package com.bdqx.pojo;

import javax.print.attribute.standard.DateTimeAtCompleted;
import javax.xml.crypto.Data;
import java.sql.Date;

public class Record {
    private String clientName;
    private String clientID;
    private String roomID;
    private Date bookInDate;
    private Date checkDate;
    private double totalMoney;
    private String remark;

    @Override
    public String toString() {
        return "Record{" +
                "clientName='" + clientName + '\'' +
                ", clientID='" + clientID + '\'' +
                ", roomID='" + roomID + '\'' +
                ", bookInDate=" + bookInDate +
                ", checkDate=" + checkDate +
                ", totalMoney=" + totalMoney +
                ", remark='" + remark + '\'' +
                '}';
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getClientID() {
        return clientID;
    }

    public void setClientID(String clientID) {
        this.clientID = clientID;
    }

    public String getRoomID() {
        return roomID;
    }

    public void setRoomID(String roomID) {
        this.roomID = roomID;
    }

    public Date getBookInDate() {
        return bookInDate;
    }

    public void setBookInDate(Date bookInDate) {
        this.bookInDate = bookInDate;
    }

    public Date getCheckDate() {
        return checkDate;
    }

    public void setCheckDate(Date checkDate) {
        this.checkDate = checkDate;
    }

    public double getTotalMoney() {
        return totalMoney;
    }

    public void setTotalMoney(double totalMoney) {
        this.totalMoney = totalMoney;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}
