package com.bdqx.web.servlet;

import com.bdqx.service.ClientService;
import com.bdqx.service.RecordService;
import com.bdqx.service.impl.ClientServiceImpl;
import com.bdqx.service.impl.RecordServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;

@WebServlet(name = "DeleteClientServlet", value = "/deleteClient")
public class DeleteClientServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");

        String clientID = request.getParameter("clientID");

        ClientService clientService = new ClientServiceImpl();

        try {
            clientService.delete(clientID);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        request.getRequestDispatcher("/listClient?currentPage=1").forward(request, response);

    }
}
