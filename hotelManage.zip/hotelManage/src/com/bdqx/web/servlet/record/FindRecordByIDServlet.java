package com.bdqx.web.servlet.record;

import com.bdqx.pojo.Client;
import com.bdqx.pojo.Record;
import com.bdqx.service.ClientService;
import com.bdqx.service.RecordService;
import com.bdqx.service.impl.ClientServiceImpl;
import com.bdqx.service.impl.RecordServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;

@WebServlet(name = "FindRecordByIDServlet", value = "/findRecordByID")
public class FindRecordByIDServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=utf-8");

        String clientID = request.getParameter("clientID");
        Date bookInDate = Date.valueOf(request.getParameter("bookInDate"));

        RecordService recordService = new RecordServiceImpl();
        ClientService clientService = new ClientServiceImpl();
        Record record = null;
        Client client = null;
        try {
            record = recordService.find(clientID, bookInDate);
            client = clientService.findByID(clientID);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        request.setAttribute("client", client);
        request.setAttribute("record", record);
        request.getRequestDispatcher("/record/edit.jsp").forward(request, response);
    }
}
