package com.bdqx.web.servlet.record;

import com.bdqx.pojo.Record;
import com.bdqx.service.RecordService;
import com.bdqx.service.impl.RecordServiceImpl;

import javax.servlet.annotation.WebServlet;
import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name = "ListRecordServlet", value="/listRecord")
public class ListRecordServlet extends javax.servlet.http.HttpServlet {
    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        doGet(request,response);
    }

    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=utf-8");

        int pageRecordNum = 7;
        int currentPage = Integer.parseInt(request.getParameter("currentPage"));

        Record record = new Record();
        RecordService recordService = new RecordServiceImpl();
        List<Record> list = null;
        List<Record> pageRecord = null;

        try {
            list = recordService.list();
//            record = recordService.find(clientID, Date.valueOf(bookInDate));
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        int recordNum = list.size();
        int startRow = currentPage*pageRecordNum-pageRecordNum;

        int finalPage = recordNum/pageRecordNum;
        if (recordNum%pageRecordNum!=0){
            finalPage += 1;
        }

        try {
            pageRecord = recordService.pageList(startRow, pageRecordNum);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }


        request.setAttribute("recordList",pageRecord);
        request.setAttribute("currentPage", currentPage);
        request.setAttribute("finalPage", finalPage);
        request.getRequestDispatcher("/record/list.jsp").forward(request,response);
    }
}
