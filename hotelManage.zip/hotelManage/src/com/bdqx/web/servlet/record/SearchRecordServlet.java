package com.bdqx.web.servlet.record;

import com.bdqx.pojo.Client;
import com.bdqx.pojo.Record;
import com.bdqx.service.ClientService;
import com.bdqx.service.RecordService;
import com.bdqx.service.impl.ClientServiceImpl;
import com.bdqx.service.impl.RecordServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

@WebServlet(name = "SearchRecordServlet", value = "/searchRecord")
public class SearchRecordServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=utf-8");

        int pageRecordNum = 7;
        int currentPage = Integer.parseInt(request.getParameter("currentPage"));
        String clientName = request.getParameter("search_clientName");
        String clientID = request.getParameter("search_clientID");
        String clientSex = request.getParameter("search_clientSex");
        String clientPhone = request.getParameter("search_clientPhone");
        String roomID = request.getParameter("search_roomID");
        String isVip = request.getParameter("search_isVip");
        String bookInDate = request.getParameter("search_bookInDate");
        String checkDate = request.getParameter("search_checkDate");
        String empty = "0";
        String yes = "1";
        String no = "2";

        String sql = "select * from clientbookin where ";
        if (clientName != ""){
            sql = sql +"clientName='"+clientName+"' and ";
        }
        if (clientID != ""){
            sql = sql +"clientID='"+clientID+"' and ";
        }
        if (!clientSex.equals(empty)){
            if (clientSex.equals(yes)){
                sql = sql +"clientID in (select clientID from client where clientSex='男')"+" and ";
            }else if (clientSex.equals(no)){
                sql = sql +"clientID in (select clientID from client where clientSex='女')"+" and ";
            }
        }
        if (!isVip.equals(empty)){
            if (isVip.equals(yes)){
                sql = sql +"clientID in (select clientID from client where isVip=1)"+" and ";
            }else if (isVip.equals(no)){
                sql = sql +"clientID in (select clientID from client where isVip=2)"+" and ";
            }
        }
        if (clientPhone != ""){
            sql = sql +"clientID in (select clientID from client where clientPhone='"+clientPhone+"') and ";
        }
        if (roomID != ""){
            sql = sql +"roomID='"+roomID+"' and ";
        }
        if (bookInDate != ""){
            sql = sql +"bookInDate='"+bookInDate+"' and ";
        }
        if (checkDate != ""){
            sql = sql +"checkDate='"+checkDate+"' and ";
        }
        if(sql.length() == 33){
            sql = sql.substring(0, sql.length()-7);
        }else{
            sql = sql.substring(0, sql.length()-5);
        }

        RecordService recordService = new RecordServiceImpl();
        List<Record> list = null;
        List<Record> pageList = null;

        try {
            list = recordService.search(sql);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        int recordNum = list.size();
        int startRow = currentPage*pageRecordNum-pageRecordNum;

        sql = sql + " limit "+startRow+" , "+pageRecordNum;
        try {
            pageList = recordService.search(sql);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        request.setAttribute("search_clientName", clientName);
        request.setAttribute("search_clientID", clientID);
        request.setAttribute("search_clientSex", clientSex);
        request.setAttribute("search_clientPhone", clientPhone);
        request.setAttribute("search_roomID", roomID);
        request.setAttribute("search_isVip", isVip);
        request.setAttribute("search_bookInDate", bookInDate);
        request.setAttribute("search_checkDate", checkDate);
        request.setAttribute("recordList", pageList);
        request.setAttribute("currentPage", currentPage);
        request.setAttribute("finalPage", recordNum/pageRecordNum+1);
        request.getRequestDispatcher("/record/list.jsp").forward(request,response);

//        request.setAttribute("client", client);
//        request.setAttribute("record", record);
//        request.getRequestDispatcher("/record/edit.jsp").forward(request, response);
    }
}
