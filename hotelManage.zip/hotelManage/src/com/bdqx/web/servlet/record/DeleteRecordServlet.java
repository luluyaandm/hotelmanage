package com.bdqx.web.servlet.record;

import com.bdqx.service.RecordService;
import com.bdqx.service.impl.RecordServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;

@WebServlet(name = "DeleteRecordServlet", value = "/deleteRecord")
public class DeleteRecordServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");

        String clientID = request.getParameter("clientID");
        Date bookInDate = Date.valueOf(request.getParameter("bookInDate"));

        RecordService recordService =new RecordServiceImpl();

        try {
            recordService.delete(clientID, bookInDate);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        request.getRequestDispatcher("/listRecord?currentPage=1").forward(request, response);

    }
}
