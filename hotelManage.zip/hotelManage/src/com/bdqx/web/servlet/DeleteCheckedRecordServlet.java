package com.bdqx.web.servlet;

import com.bdqx.service.RecordService;
import com.bdqx.service.impl.RecordServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name = "DeleteCheckedRecordServlet", value = "/deleteCheckedRecord")
public class DeleteCheckedRecordServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");

        System.out.println(1);

        String checkedRecord = request.getParameter("checkedRecord");
        System.out.println(checkedRecord);
        String[] record = checkedRecord.split(";");
        int len = record.length;
        String clientID;
        Date bookInDate;

        RecordService recordService =new RecordServiceImpl();

        try {
            for(int i=0;i<len;i=i+2) {
                clientID = record[i];
                bookInDate = Date.valueOf(record[i+1]);
                System.out.println(clientID+bookInDate);
                recordService.delete(clientID, bookInDate);
            }

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        request.getRequestDispatcher("/listRecord?currentPage=1").forward(request, response);

    }
}
