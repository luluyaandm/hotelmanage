package com.bdqx.web.servlet.client;

import com.bdqx.pojo.Client;
import com.bdqx.pojo.Record;
import com.bdqx.service.ClientService;
import com.bdqx.service.RecordService;
import com.bdqx.service.impl.ClientServiceImpl;
import com.bdqx.service.impl.RecordServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name = "ListClientServlet", value = "/listClient")
public class ListClientServlet extends HttpServlet {
    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        doGet(request,response);
    }

    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=utf-8");

        int pageClientNum = 7;
        int currentPage = Integer.parseInt(request.getParameter("currentPage"));

        Client client = new Client();
        ClientService clientService = new ClientServiceImpl();
        List<Client> list = null;
        List<Client> pageClient = null;

        try {
            list = clientService.list();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        int clientNum = list.size();
        int startRow = currentPage*pageClientNum-pageClientNum;

        int finalPage = clientNum/pageClientNum;
        if (clientNum%pageClientNum!=0){
            finalPage += 1;
        }

        try {
            pageClient = clientService.listPage(startRow,  pageClientNum);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        request.setAttribute("clientList",pageClient);
        request.setAttribute("currentPage", currentPage);
        request.setAttribute("finalPage", finalPage);
        request.getRequestDispatcher("/client/clientlist.jsp").forward(request,response);
    }
}
