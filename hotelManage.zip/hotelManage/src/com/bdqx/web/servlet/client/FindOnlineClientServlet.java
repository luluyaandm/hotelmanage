package com.bdqx.web.servlet.client;

import com.bdqx.pojo.Client;
import com.bdqx.pojo.Record;
import com.bdqx.pojo.Room;
import com.bdqx.service.ClientService;
import com.bdqx.service.RecordService;
import com.bdqx.service.impl.ClientServiceImpl;
import com.bdqx.service.impl.RecordServiceImpl;
import com.bdqx.service.impl.RoomServiceImpl;
import com.bdqx.web.servlet.room.RoomServlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.ref.ReferenceQueue;
import java.sql.SQLException;
import java.util.List;

@WebServlet(name = "FindOnlineClientServlet", value = "/findOnlineClient")
public class FindOnlineClientServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=utf-8");

        String clientID = request.getParameter("clientID");
        String bookInDate = request.getParameter("bookInDate");

        RecordService recordService = new RecordServiceImpl();
        RoomServiceImpl roomServlet = new RoomServiceImpl();
        Record record = null;
        List<Room> list = null;

        try {
            record = recordService.findOnlineClinet(clientID, bookInDate);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        list = roomServlet.findAllRoom();

        System.out.println(record);
        request.setAttribute("roomList", list);
        request.setAttribute("record", record);
        request.getRequestDispatcher("client/onlineclientedit.jsp").forward(request, response);
    }
}
