package com.bdqx.web.servlet.client;

import com.bdqx.pojo.Record;
import com.bdqx.service.ClientService;
import com.bdqx.service.RecordService;
import com.bdqx.service.impl.ClientServiceImpl;
import com.bdqx.service.impl.RecordServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet(name = "ListClientOnlineServlet", value = "/listClientOnline")
public class ListClientOnlineServlet extends HttpServlet {
    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        doGet(request,response);
    }

    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=utf-8");

        int pageRecordNum = 5;
        int currentPage = Integer.parseInt(request.getParameter("currentPage"));

        ClientService clientService = new ClientServiceImpl();
        List<Record> list = null;
        List<Record> pageRecord = null;

        try {
            list = clientService.listOnline();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        int recordNum = list.size();
        int startRow = currentPage*pageRecordNum-pageRecordNum;

        int finalPage = recordNum/pageRecordNum;
        if (recordNum%pageRecordNum!=0){
            finalPage += 1;
        }

        try {
            pageRecord = clientService.listPageOnline(startRow, pageRecordNum);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }


        request.setAttribute("clientOnline",pageRecord);
        request.setAttribute("currentPage", currentPage);
        request.setAttribute("finalPage", finalPage);
        request.getRequestDispatcher("info.jsp").forward(request,response);
    }
}
