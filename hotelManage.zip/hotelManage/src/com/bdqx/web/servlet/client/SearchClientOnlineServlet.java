package com.bdqx.web.servlet.client;

import com.bdqx.pojo.Client;
import com.bdqx.pojo.Record;
import com.bdqx.service.ClientService;
import com.bdqx.service.impl.ClientServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet(name = "SearchClientOnlineServlet", value = "/searchClientOnline")
public class SearchClientOnlineServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=utf-8");

        int pageRecordNum = 7;
        int currentPage = Integer.parseInt(request.getParameter("currentPage"));
        String clientName = request.getParameter("so_clientName");
        String clientID = request.getParameter("so_clientID");
        String roomID = request.getParameter("so_roomID");
        String bookInDate = request.getParameter("so_bookInDate");


        String sql = "select * from clientbookin where checkDate is null and ";
        if (clientName != ""){
            sql = sql +"clientName='"+clientName+"' and ";
        }
        if (clientID != "") {
            sql = sql + "clientID='" + clientID + "' and ";
        }
        if (roomID != ""){
            sql = sql +"roomID='"+ roomID +"' and ";
        }
        if (bookInDate != "") {
            sql = sql + "bookInDate='" + bookInDate + "' and ";
        }

        sql = sql.substring(0, sql.length()-5);

        System.out.println(sql);
        ClientService clientService = new ClientServiceImpl();
        List<Record> list = null;
        List<Record> pageList = null;

        try {
            list = clientService.searchOnline(sql);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        System.out.println(list);
        int recordNum = list.size();
        int startRow = currentPage*pageRecordNum-pageRecordNum;

        int finalPage = recordNum/pageRecordNum;
        if (recordNum%pageRecordNum!=0){
            finalPage += 1;
        }

        sql = sql + " limit "+startRow+" , "+pageRecordNum;

        try {
            pageList = clientService.searchOnline(sql);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        request.setAttribute("search_clientName", clientName);
        request.setAttribute("search_clientID", clientID);
        request.setAttribute("search_roomID", roomID);
        request.setAttribute("search_bookInDate", bookInDate);
        request.setAttribute("clientOnline", pageList);
        request.setAttribute("currentPage", currentPage);
        request.setAttribute("finalPage", finalPage);
        request.getRequestDispatcher("info.jsp").forward(request,response);
    }
}

