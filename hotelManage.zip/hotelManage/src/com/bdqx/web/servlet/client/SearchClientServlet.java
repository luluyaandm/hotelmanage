package com.bdqx.web.servlet.client;

import com.bdqx.pojo.Client;
import com.bdqx.pojo.Record;
import com.bdqx.service.ClientService;
import com.bdqx.service.RecordService;
import com.bdqx.service.impl.ClientServiceImpl;
import com.bdqx.service.impl.RecordServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet(name = "SearchClientServlet", value = "/searchClient")
public class SearchClientServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=utf-8");

        int pageClientNum = 7;
        int currentPage = Integer.parseInt(request.getParameter("currentPage"));
        String clientName = request.getParameter("s_clientName");
        String clientID = request.getParameter("s_clientID");
        String clientSex = request.getParameter("s_clientSex");
        String clientPhone = request.getParameter("s_clientPhone");
        String isVip = request.getParameter("s_isVip");
        String empty = "0";
        String yes = "1";
        String no = "2";

        String sql = "select * from client where ";
        if (clientName != ""){
            sql = sql +"clientName='"+clientName+"' and ";
        }
        if (clientID != ""){
            sql = sql +"clientID='"+clientID+"' and ";
        }
        if (!clientSex.equals(empty)){
            if (clientSex.equals(yes)){
                sql = sql +"clientSex='男'"+" and ";
            }else if (clientSex.equals(no)){
                sql = sql +"clientSex='女'"+" and ";
            }
        }
        if (!isVip.equals(empty)){
            if (isVip.equals(yes)){
                sql = sql +"isVip=1"+" and ";
            }else if (isVip.equals(no)){
                sql = sql +"isVip=2"+" and ";
            }
        }
        if (clientPhone != ""){
            sql = sql +"clientPhone='"+clientPhone+"' and ";
        }

        if(sql.length() == 27){
            sql = sql.substring(0, sql.length()-7);
        }else{
            sql = sql.substring(0, sql.length()-5);
        }

        ClientService clientService = new ClientServiceImpl();
        List<Client> list = null;
        List<Client> pageList = null;

        try {
            list = clientService.search(sql);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        int clientNum = list.size();
        int startRow = currentPage*pageClientNum-pageClientNum;

        sql = sql + " limit "+startRow+" , "+pageClientNum;

        try {
            pageList = clientService.search(sql);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        request.setAttribute("s_clientName", clientName);
        request.setAttribute("s_clientID", clientID);
        request.setAttribute("s_clientSex", clientSex);
        request.setAttribute("s_clientPhone", clientPhone);
        request.setAttribute("s_isVip", isVip);
        request.setAttribute("clientList", pageList);
        request.setAttribute("currentPage", currentPage);
        request.setAttribute("finalPage", clientNum/pageClientNum+1);
        request.getRequestDispatcher("client/clientlist.jsp").forward(request,response);
    }
}
