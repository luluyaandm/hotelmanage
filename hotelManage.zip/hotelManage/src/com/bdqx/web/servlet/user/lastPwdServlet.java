package com.bdqx.web.servlet.user;

import com.bdqx.util.C3P0Util;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet(name = "lastPwdServlet",urlPatterns = "/lastpwdservlet")
public class lastPwdServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=utf-8");


        String userName = (String) request.getSession().getAttribute("userName");
        String pwd = request.getParameter("userPwd");



        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            connection = C3P0Util.getConnection();
            statement = connection.prepareStatement("select * from user where userName = ?and userPwd = ?");
            statement.setString(1,userName);
            statement.setString(2,pwd);
            resultSet =statement.executeQuery();
            if (resultSet.next()){
                response.getWriter().print("<font color='green'size = 3px>原始密码输入正确</font>");
            }else {
                response.getWriter().print("<font color='red' size = 3px>密码输入错误，请重新输入</font>");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            C3P0Util.release(connection,resultSet,statement);
        }


    }
}
