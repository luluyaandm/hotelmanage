package com.bdqx.web.servlet.user;

import com.bdqx.pojo.User;
import com.bdqx.service.UserService;
import com.bdqx.service.impl.UserServiceImpl;
import org.apache.commons.beanutils.BeanUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "addUserServlet",urlPatterns = "/adduser")
public class addUserServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=utf-8");

        User user = new User();
        try {
            BeanUtils.populate(user,request.getParameterMap());
            UserService userService = new UserServiceImpl();
            user.setUserID(userService.list().size()+1);
            userService.addUSer(user);
        } catch (Exception e) {
            e.printStackTrace();
        }

        request.getRequestDispatcher("user/adduser.jsp").forward(request,response);

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}
