package com.bdqx.web.servlet.user;

import com.bdqx.service.UserService;
import com.bdqx.service.impl.UserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "fixUserPwdServlet",urlPatterns = "/fixpwd")
public class fixUserPwdServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=utf-8");

        String userName = (String) request.getSession().getAttribute("userName");
        String newPwd = request.getParameter("newpass");

        UserService userService = new UserServiceImpl();
        int i=userService.fixUserPwd(userName,newPwd);
        if (i>0)
        {
            request.setAttribute("msg","<font color = 'green'>当前管理员密码修改成功</font>");
            request.getRequestDispatcher("user/userpass.jsp").forward(request,response);
        }else
        {
            request.setAttribute("msg","<font color = 'red'>当前管理员密码修改失败，请重新尝试</font>");
            request.getRequestDispatcher("user/userpass.jsp").forward(request,response);
        }

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}
