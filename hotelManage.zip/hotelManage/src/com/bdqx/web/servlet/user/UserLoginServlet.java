package com.bdqx.web.servlet.user;

import com.bdqx.pojo.User;
import com.bdqx.service.UserService;
import com.bdqx.service.impl.UserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "UserLoginServlet",urlPatterns = "/userLogin")
public class UserLoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=utf-8");



        String name = request.getParameter("userName");
        String pwd = request.getParameter("userPwd");
        String code =(String) request.getSession().getAttribute("vcode");
        String myCode = request.getParameter("code");

        if (code == null)
        {
            request.getRequestDispatcher("/login.jsp").forward(request,response);
            return;
        }

        if (!myCode.equalsIgnoreCase(code))
        {
            request.setAttribute("msg","验证码有误");
            request.getRequestDispatcher("/login.jsp").forward(request,response);
            return;
        }

        UserService userService = new UserServiceImpl();
        User user = userService.login(name,pwd);
         if (user!=null)
         {
             request.getSession().setAttribute("user",user);
             request.getSession().setAttribute("userName",user.getUserName());
             request.getRequestDispatcher("/index.jsp").forward(request,response);
         }else
         {
             request.setAttribute("tips","用户名或密码有误, 请检查后重新输入");
             request.getRequestDispatcher("/login.jsp").forward(request,response);

         }

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}
