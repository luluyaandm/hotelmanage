package com.bdqx.web.servlet.user;

import com.bdqx.pojo.PageBean;
import com.bdqx.pojo.User;
import com.bdqx.service.UserService;
import com.bdqx.service.impl.UserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "UserListServlet",urlPatterns = "/userlist")
public class UserListServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=utf-8");


        String currentpage = request.getParameter("currentPage");
        String rows = request.getParameter("rows");

        if (currentpage == null||"".equals(currentpage))
        {
            currentpage = "1";

        }

        if (rows == null||"".equals(rows)){
            rows = "8";
        }


        UserService userService = new UserServiceImpl();
        PageBean<User> pageBean = userService.findUserByPage(currentpage,rows);


        request.setAttribute("pb",pageBean);

        request.getRequestDispatcher("user/adminlist.jsp").forward(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        doPost(request,response);
    }
}
