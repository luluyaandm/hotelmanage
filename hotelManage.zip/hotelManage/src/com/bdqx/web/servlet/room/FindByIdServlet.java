package com.bdqx.web.servlet.room;

import com.bdqx.pojo.Room;
import com.bdqx.service.impl.RoomServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "FindByIdServlet",urlPatterns = "/findbyid")
public class FindByIdServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id = request.getParameter("id");
        RoomServiceImpl bs= new RoomServiceImpl();
        Room room =bs.findRoomById(id);

        request.setAttribute("room",room);
        request.getRequestDispatcher("room/editroom.jsp").forward(request,response);
    }
}
