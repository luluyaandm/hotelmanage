package com.bdqx.web.servlet.room;

import com.bdqx.pojo.Room;
import com.bdqx.service.impl.RoomServiceImpl;
import org.apache.commons.beanutils.BeanUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "AddRoomServlet",urlPatterns = "/addroomservlet")
public class AddRoomServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=utf-8");
        Room room=new Room();
        try{
            BeanUtils.populate(room,request.getParameterMap());
            System.out.println(room);
        } catch (Exception e) {
            e.printStackTrace();
        }
        //调用业务逻辑方法
        RoomServiceImpl bsi=new RoomServiceImpl();
        bsi.addRoom(room);

        //分发转向
        request.getRequestDispatcher("/findroombypage").forward(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
