package com.bdqx.web.servlet.room;

import com.bdqx.pojo.Room;
import com.bdqx.service.impl.RoomServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "RoomServlet",urlPatterns = "/roomservlet")
public class RoomServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=utf-8");
        //当你在当前这个servlet把这个数据库里的所有房间查找到后，你要在list.jsp显示，必须要转发到list.jsp
        //调用业务逻辑
        RoomServiceImpl bsi = new RoomServiceImpl();
        List<Room> rooms =bsi.findAllRoom();
        //分发转向，跳转页面
        if(rooms !=null){
            request.setAttribute("rooms",rooms);
            request.getRequestDispatcher("/room/roomlist.jsp").forward(request,response);
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
