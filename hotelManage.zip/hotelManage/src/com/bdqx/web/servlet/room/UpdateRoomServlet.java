package com.bdqx.web.servlet.room;

import com.bdqx.pojo.Room;
import com.bdqx.service.impl.RoomServiceImpl;
import org.apache.commons.beanutils.BeanUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "UpdateRoomServlet",urlPatterns = "/updateroom")
public class UpdateRoomServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        Room room = new Room();
        try {
            BeanUtils.populate(room, request.getParameterMap());
        } catch (Exception e) {
            e.printStackTrace();
        }

        RoomServiceImpl bs = new RoomServiceImpl();
        bs.updateRoom(room);
        System.out.println(room);


        //跳转
        request.getRequestDispatcher("/findroombypage").forward(request, response);
    }
}
