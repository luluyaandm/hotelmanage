package com.bdqx.service;

import com.bdqx.pojo.Record;

import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

public interface RecordService {
    public List<Record> list() throws SQLException;

    public List<Record> pageList(int currentPage, int pageNum) throws SQLException;

    public void update(Record record) throws SQLException;

    public Record find(String clientID, Date bookInDate) throws SQLException;

    public void delete(String clientID, Date bookInDate) throws SQLException;

    public List<Record> search(String sql) throws SQLException;

    public void add(Record record) throws SQLException;

    public Record findOnlineClinet(String clientID, String bookInDate) throws SQLException;
}
