package com.bdqx.service;

import com.bdqx.pojo.Client;
import com.bdqx.pojo.Record;

import java.sql.SQLException;
import java.util.List;

public interface ClientService {
    public Client findByID(String clientID) throws SQLException;
    public List<Client> list() throws SQLException;
    public List<Client> listPage(int currentPage, int pageRecordNum) throws SQLException;
    public List<Record> listOnline() throws SQLException;
    public List<Record> listPageOnline(int currentPage, int pageRecordNum) throws SQLException;
    public void update(Client client) throws SQLException;
    public void add(Client client) throws SQLException;
    public void delete(String clientID) throws SQLException;
    public List<Client> search(String sql) throws SQLException;
    public void checkOut(String clientID, String bookInDate, String checkDate) throws SQLException;
    public List<Record> searchOnline(String sql) throws SQLException;
}
