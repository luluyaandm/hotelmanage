package com.bdqx.service.impl;

import com.bdqx.dao.UserDao;
import com.bdqx.dao.impl.UserDaoImpl;
import com.bdqx.pojo.PageBean;
import com.bdqx.pojo.User;
import com.bdqx.service.UserService;

import java.sql.SQLException;
import java.util.List;

public class UserServiceImpl implements UserService {

    UserDao userDao = new UserDaoImpl();

    @Override
    public User login(String userName, String userPwd) {
        return  userDao.findUser(userName,userPwd);
    }

    @Override
    public List<User> findAllUser() throws SQLException {
        return userDao.findAlluser();
    }

    @Override
    public PageBean<User> findUserByPage(String currentPage, String rows) {
        int _currentPage = Integer.parseInt(currentPage);
        int _rows = Integer.parseInt(rows);

        if (_currentPage<=0){
            _currentPage = 1;
        }

        PageBean<User> pageBean = new PageBean<User>();
        pageBean.setCurrentPage(_currentPage);
        pageBean.setRows(_rows);

        int totalCount = userDao.findTotalCount();
        pageBean.setTotalCount(totalCount);

        int start = (_currentPage -1)*_rows;
        List<User> list = userDao.findByPage(start,_rows);
        pageBean.setList(list);

        int totalPage = (totalCount % _rows) ==0?totalCount/_rows:(totalCount/_rows)+1;
        pageBean.setTotalPage(totalPage);

        return pageBean;
    }

    @Override
    public int fixUserPwd(String userName, String newPwd) {
       return userDao.updateUserPwd(userName,newPwd);
    }

    @Override
    public User findUserById(String userId) throws SQLException{
        return userDao.findUserById(userId);
    }

    @Override
    public void updateUser(User user) throws SQLException {
        userDao.updateUser(user);
    }

    @Override
    public void deleteUser(String userID) throws SQLException {
        userDao.deleteUser(userID);
    }

    @Override
    public void deleteSelectUser(String[] ids) throws SQLException {
        if (ids != null && ids.length > 0 )
        {
            for (String id : ids) {
                userDao.deleteUser(id);
            }
        }
    }

    @Override
    public void addUSer(User user) throws SQLException{
        userDao.addUser(user);
    }

    @Override
    public List<User> list() throws SQLException {
        return userDao.listUser();
    }
}
