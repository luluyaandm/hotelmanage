package com.bdqx.service.impl;

import com.bdqx.dao.impl.RoomDaoImpl;
import com.bdqx.pojo.Room;

import java.sql.SQLException;
import java.util.List;

public class RoomServiceImpl {
    RoomDaoImpl roomDao = new RoomDaoImpl();

    public List<Room> findAllRoom(){
        try {
            return roomDao.findAllRoom();
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }
    public void addRoom(Room room){
        try{
            roomDao.addRoom(room);
        }catch (SQLException e){
            e.printStackTrace();
        }
    }
    public Room findRoomById(String id) {
        try {
            return roomDao.findRoomById(id);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void updateRoom(Room room) {
        try {
            roomDao.updateRoom(room);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void deleteRoom(String id) {
        try {
            roomDao.deleteRoom(id);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public List<Room> findRoomByType(String roomTypeName) throws SQLException {
        return roomDao.findRoomByType(roomTypeName);
    }
}
