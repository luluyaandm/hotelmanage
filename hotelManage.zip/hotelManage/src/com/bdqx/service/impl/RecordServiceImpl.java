package com.bdqx.service.impl;

import com.bdqx.dao.RecordDao;
import com.bdqx.dao.impl.RecordDaoImpl;
import com.bdqx.pojo.Record;
import com.bdqx.service.RecordService;

import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

public class RecordServiceImpl implements RecordService {
    RecordDao recordDao =new RecordDaoImpl();

    @Override
    public List<Record> list() throws SQLException {
        return recordDao.listRecord();
    }

    @Override
    public List<Record> pageList(int currentPage, int pageNum) throws SQLException {
        return recordDao.listPageRecord(currentPage, pageNum);
    }

    @Override
    public void update(Record record) throws SQLException {
        recordDao.updateRecord(record);
    }

    @Override
    public Record find(String clientID, Date bookInDate) throws SQLException {
        return recordDao.findRcord(clientID, bookInDate);
    }

    @Override
    public void delete(String clientID, Date bookInDate) throws SQLException {
        recordDao.deleteRecord(clientID, bookInDate);
    }

    @Override
    public List<Record> search(String sql) throws SQLException {
        return recordDao.searchRecord(sql);
    }

    @Override
    public void add(Record record) throws SQLException {
        recordDao.addRecord(record);
    }

    @Override
    public Record findOnlineClinet(String clientID, String bookInDate) throws SQLException {
        return recordDao.findOnlineClient(clientID, bookInDate);
    }
}
