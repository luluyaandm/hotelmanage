package com.bdqx.service.impl;

import com.bdqx.dao.ClientDao;
import com.bdqx.dao.impl.ClientDaoImpl;
import com.bdqx.pojo.Client;
import com.bdqx.pojo.Record;
import com.bdqx.service.ClientService;

import java.sql.SQLException;
import java.util.List;

public class ClientServiceImpl implements ClientService {
    ClientDao clientDao = new ClientDaoImpl();

    @Override
    public Client findByID(String clientID) throws SQLException {
        return  clientDao.findClientByID(clientID);
    }

    @Override
    public List<Client> list() throws SQLException {
        return clientDao.listClient();
    }

    @Override
    public List<Client> listPage(int currentPage, int pageRecordNum) throws SQLException {
        return clientDao.listPageClient(currentPage, pageRecordNum);
    }

    @Override
    public List<Record> listOnline() throws SQLException {
        return clientDao.listClientOnline();
    }

    @Override
    public List<Record> listPageOnline(int currentPage, int pageRecordNum) throws SQLException {
        return clientDao.listPageClientOnline(currentPage, pageRecordNum);
    }

    @Override
    public void update(Client client) throws SQLException {
        clientDao.updateClient(client);
    }

    @Override
    public void add(Client client) throws SQLException {
        clientDao.addClinet(client);
    }

    @Override
    public void delete(String clientID) throws SQLException {
        clientDao.deleteClient(clientID);
    }

    @Override
    public List<Client> search(String sql) throws SQLException {
        return clientDao.searchClient(sql);
    }

    @Override
    public void checkOut(String clientID, String bookInDate, String checkDate) throws SQLException {
        clientDao.checkOutClinet(clientID, bookInDate, checkDate);
    }

    @Override
    public List<Record> searchOnline(String sql) throws SQLException {
        return clientDao.searchClientOnline(sql);
    }
}
