package com.bdqx.service;

import com.bdqx.pojo.PageBean;
import com.bdqx.pojo.Room;

import java.util.Map;

public interface PageService {
    /**
     * 分页条件查询
     * @param currentPage
     * @param rows
     * @param condition
     * @return
     */
    PageBean<Room> findRoomByPage(String currentPage, String rows, Map<String, String[]> condition);
}
