package com.bdqx.service;

import com.bdqx.pojo.PageBean;
import com.bdqx.pojo.User;

import java.sql.SQLException;
import java.util.List;

public interface UserService {
    public User login(String userName,String userPwd);
    public List<User> findAllUser() throws SQLException;
    public PageBean<User> findUserByPage(String currentPage,String rows);
    public int fixUserPwd(String userName,String newPwd);
    public User findUserById(String userId)throws SQLException;
    public void updateUser(User user) throws SQLException;
    public void deleteUser(String userID) throws SQLException;
    public void deleteSelectUser(String[] ids)throws SQLException;
    public void addUSer(User user)throws SQLException;
    public List<User> list() throws SQLException;
}
